package ${PACKAGE_NAME};

import android.app.Application;

/**
 * @author  ${USER}
 * @date ${DATE} ${TIME}
 * @desc ${desc}
 */
#parse("File Header.java")
public class ${NAME} extends Application {
}
