package ${PACKAGE_NAME};

import android.app.Activity;
import android.os.Bundle;

/**
 * @author  ${USER}
 * @date ${DATE} ${TIME}
 * @desc ${desc}
 */
#parse("File Header.java")
public class ${NAME} extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}