#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
interface ${NAME} {

    interface IModel : IBaseMvp.IBaseModel

    interface IView : IBaseMvp.IBaseView

    interface IPresenter<M : IModel, V : IView> : IBaseMvp.IBasePresenter<M, V>
}